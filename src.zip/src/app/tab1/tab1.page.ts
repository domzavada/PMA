import { Component } from '@angular/core';
import { WordsService } from '../api/words.service';
import { LoadingController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { HistoryRecord } from '../models/history-record.model';
import { HistoryService } from '../api/history.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})

export class Tab1Page {
  myInput: String = ""
  loadingDialog: any
  definitions: String = ""
  pronunciation: String = ""
  synonyms : String = ""
  partOfSpeech : String = ""
  typeOf : String = ""
  derivation: String = ""
  examples: String = ""

  constructor(private wordsService: WordsService, private historyService: HistoryService, private alertCtrl: AlertController, public loadingController: LoadingController) {
    this.myInput;
    this.definitions;
    this.pronunciation;
    this.synonyms;
    this.partOfSpeech;
    this.typeOf;
    this.derivation;
    this.examples;
  }

  getDefinitions() {
    this.wordsService.getDefinitions(this.myInput).subscribe((data:any) => {
      this.definitions = "";
      if (data.definitions.length == 0) {
        this.definitions = "There are no found definitions.";
      } else{      
        for (var i = 0; i < data.definitions.length; i++) {
            this.definitions += i+1 + '. ' + data.definitions[i].definition + ". ";         
        }
      }
    return this.definitions;
    });
  }

  getPronunciation() {
    this.wordsService.getPronunciation(this.myInput).subscribe((data:any) => {
      this.pronunciation = "";
      if (data.pronunciation.length == 0) {
        this.pronunciation = "There are no found pronunciation.";
      } else{         
          this.pronunciation += 1 + '. ' + data.pronunciation.all + ". ";    
        }
        return this.pronunciation;
    });
  }

  getSynonyms() {
    this.wordsService.getSynonyms(this.myInput).subscribe((data:any) => {
      this.synonyms = "";
      if (data.synonyms.length == 0) {
        this.synonyms = "There are no found synonyms.";
      } else{   
        for (var i = 0; i < data.synonyms.length; i++) {
          if (data.synonyms.length == 0 || i == data.synonyms.length - 1) {
            this.synonyms += i+1 + '. ' + data.synonyms[i] + ". ";
          } else {
            this.synonyms += i+1 + '. ' + data.synonyms[i] + ", ";
          }
        }
      }
      return this.synonyms;
    });  
  }

  getPartOfSpeech() {
    this.wordsService.getPartOfSpeech(this.myInput).subscribe((data:any) => {
      this.partOfSpeech = "";
      if (data.partOfSpeech.length == 0) {
        this.partOfSpeech = "There are no found part of speech.";
      } else{   
        for (var i = 0; i < data.partOfSpeech.length; i++) {
          if (data.partOfSpeech.length == 0 || i == data.partOfSpeech.length - 1 ) {
            this.partOfSpeech += i+1 + '. ' + data.partOfSpeech[i]+ ". ";
          } else {
            this.partOfSpeech +=i+1 + '. ' +  data.partOfSpeech[i] + ", ";
          }
        }
      }
      return this.partOfSpeech;
    });   
  }

  gettypeOf() {
    this.wordsService.gettypeOf(this.myInput).subscribe((data:any) => {
      this.typeOf = "";
      if (data.typeOf.length == 0) {
        this.typeOf = "There are no found type of word.";
      } else{   
        for (var i = 0; i < data.typeOf.length; i++) {
          if (data.typeOf.length == 0 || i == data.typeOf.length - 1 ) {
              this.typeOf +=i+1 + '. ' +  data.typeOf[i] + ". ";
          } else {
              this.typeOf +=i+1 + '. ' +  data.typeOf[i] + ", ";
          }
        }
      }
      return this.typeOf;
    });
  }

  getDerivation() {
    this.wordsService.getDerivation(this.myInput).subscribe((data:any) => {
      this.derivation = "";
      if (data.derivation.length == 0) {
        this.derivation = "There are no found derivations.";
      } else{   
        for (var i = 0; i < data.derivation.length; i++) {
            this.derivation += i+1 + '. ' + data.derivation[i] + ". ";
        }
      }
      return this.derivation;  
    });
  }

  getExamples() {
    this.wordsService.getExamples(this.myInput).subscribe((data:any) => {
      this.examples = "";
      if (data.examples.length == 0) {
        this.examples = "There are no found examples.";
        } else{   
          for (var i = 0; i < data.examples.length; i++) {
              this.examples += i + 1 + ': ' + data.examples[i] + ". ";
        }
      }

      let record = new HistoryRecord(this.myInput, this.definitions, this.pronunciation, this.synonyms, this.partOfSpeech, this.typeOf, this.derivation, this.examples);
      this.historyService.saveRecord(record);

      return this.examples;
    });
  }
  //https://ionicframework.com/docs/v3/api/components/alert/AlertController/
  presentAlert() {
    const alert = this.alertCtrl.create({
    message: 'Wrong input',
    subHeader: 'Try: "example"',
    buttons: ['OK']}).then(alert=> alert.present());
  }

  async btnSearchClicked() {    
    if (this.myInput.length == 0) {
      this.presentAlert();
    } else {  
      // infinite loading, našel jsem snad možné opravení https://stackoverflow.com/questions/57290105/ionic-loadingcontroller-dismiss-is-not-working
      //this.presentLoading();
      await this.presentLoading().then(() =>{
          this.getSynonyms();
          this.getDerivation();
          this.getPartOfSpeech();
          this.gettypeOf();
          this.getDefinitions();
          this.getPronunciation();
          this.getExamples();      
        }
      );
      this.loadingDialog.dismiss(); 
    }
  }

  async presentLoading() 
  {
    this.loadingDialog = await this.loadingController.create(
    {
      message: 'Searching ...', 
    });
    await this.loadingDialog.present();
  }
}
