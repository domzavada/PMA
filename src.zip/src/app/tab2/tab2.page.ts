import { Component } from '@angular/core';
import { HistoryService } from '../api/history.service';
import { HistoryRecord } from '../models/history-record.model';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  historyArray: HistoryRecord[]
  arrayisnull : String = ""

  constructor(private historyService: HistoryService) {}

  ionViewWillEnter()
  {
    console.log('Method ionViewWillEnter was called.');
    if(this.historyService.historyArray.length < 1){
      this.arrayisnull = "History is empty."
    }
    else{
      this.arrayisnull = ""
    }
    this.historyArray = this.historyService.getRecord();

  }

}


