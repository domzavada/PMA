import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class WordsService {

  constructor(private http: HttpClient) { }

  getDefinitions(text: String) {
    return this.http.get('https://wordsapiv1.p.rapidapi.com/words/'+text+'/definitions', {
      headers: {
        "x-rapidapi-host": "wordsapiv1.p.rapidapi.com",
        "x-rapidapi-key": "44c5e38d94mshabff87d33d6a9bfp1759bajsnf47370563c7b"
      }
    });
  } 

  getPronunciation(text: String) {
    return this.http.get('https://wordsapiv1.p.rapidapi.com/words/'+text+'/pronunciation', {
      headers: {
        "x-rapidapi-host": "wordsapiv1.p.rapidapi.com",
        "x-rapidapi-key": "44c5e38d94mshabff87d33d6a9bfp1759bajsnf47370563c7b"
      }
    });
  }

  getSynonyms(text: String) {
    return this.http.get('https://wordsapiv1.p.rapidapi.com/words/'+text+'/synonyms', {
      headers: {
        "x-rapidapi-host": "wordsapiv1.p.rapidapi.com",
        "x-rapidapi-key": "44c5e38d94mshabff87d33d6a9bfp1759bajsnf47370563c7b"
      }
    });
  }

  getPartOfSpeech(text: String) {
    return this.http.get('https://wordsapiv1.p.rapidapi.com/words/'+text+'/partOfSpeech', {
      headers: {
        "x-rapidapi-host": "wordsapiv1.p.rapidapi.com",
        "x-rapidapi-key": "44c5e38d94mshabff87d33d6a9bfp1759bajsnf47370563c7b"
      }
    });
  }

  gettypeOf(text: String) {
    return this.http.get('https://wordsapiv1.p.rapidapi.com/words/'+text+'/typeOf', {
      headers: {
        "x-rapidapi-host": "wordsapiv1.p.rapidapi.com",
        "x-rapidapi-key": "44c5e38d94mshabff87d33d6a9bfp1759bajsnf47370563c7b"
      }
    });
  }

  getDerivation(text: String) {
    return this.http.get('https://wordsapiv1.p.rapidapi.com/words/'+text+'/derivation', {
      headers: {
        "x-rapidapi-host": "wordsapiv1.p.rapidapi.com",
        "x-rapidapi-key": "44c5e38d94mshabff87d33d6a9bfp1759bajsnf47370563c7b"
      }
    });
  }

  getExamples(text: String) {
    return this.http.get('https://wordsapiv1.p.rapidapi.com/words/'+text+'/examples', {
      headers: {
        "x-rapidapi-host": "wordsapiv1.p.rapidapi.com",
        "x-rapidapi-key": "44c5e38d94mshabff87d33d6a9bfp1759bajsnf47370563c7b"
      }
    });
  }
}