export class HistoryRecord 
{
    inputHistory: String
    definitionsHistory: String
    pronunciationHistory: String
    synonymsHistory: String
    partOfSpeechHistory: String
    typeOfHistory: String
    derivationHistory: String
    exampleHistory: String


    constructor(inputHistory: String, definitionsHistory: String, pronunciationHistory: String, synonymsHistory: String, partOfSpeechHistory: String, typeOfHistory: String, derivationHistory: String, exampleHistory: String,) {
        this.inputHistory = inputHistory;
        this.definitionsHistory = definitionsHistory;
        this.pronunciationHistory = pronunciationHistory;
        this.synonymsHistory = synonymsHistory;
        this.partOfSpeechHistory = partOfSpeechHistory;
        this.typeOfHistory = typeOfHistory;
        this.derivationHistory = derivationHistory; 
        this.exampleHistory = exampleHistory;
    }
}